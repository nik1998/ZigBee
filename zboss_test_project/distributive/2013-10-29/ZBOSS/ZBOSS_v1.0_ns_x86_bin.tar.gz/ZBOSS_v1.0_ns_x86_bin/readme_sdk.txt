This is ZBOSS SDK for starting ZigBee application development.
SDK provides ZBOSS libraries, includes, common development tools and a bunch of compiled tests.
All the tests are ready to run with ZBOSS Network Simulator and the enviroment is set up for
development applications under Ubuntu.

When developing applications, use tests' Makefiles as examples to build.

