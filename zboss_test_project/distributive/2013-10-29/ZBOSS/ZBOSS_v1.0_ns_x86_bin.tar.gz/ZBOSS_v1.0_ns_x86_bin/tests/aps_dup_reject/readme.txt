Check APS duplicate

2 device sending data with the same aps counter.

Result: "SUCCESS" or "FAILED"