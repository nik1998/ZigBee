
Tests Mgmt_Lqi_req/Mgmt_Lqi_resp functionality. 3 end devices and 1 router join to coordinator,
router performs Mgmt_Lqi_req and accepts Mgmt_Lqi_resp. Received neighbor table records are written
into the log file.

To execute test start run.sh

 
