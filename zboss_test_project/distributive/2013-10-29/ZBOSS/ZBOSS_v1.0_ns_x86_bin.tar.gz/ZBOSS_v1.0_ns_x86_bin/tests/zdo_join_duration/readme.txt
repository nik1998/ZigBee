This test runs ZC and set permit join timeout to 10 seconds.
First child connects successfully but the second failed to connect,
because it tries to connect after permit join timeout ends.
