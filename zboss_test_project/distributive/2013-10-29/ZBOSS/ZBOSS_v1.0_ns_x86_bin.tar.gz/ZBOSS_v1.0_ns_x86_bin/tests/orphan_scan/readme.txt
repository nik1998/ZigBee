Orphan rejoin test.

ZR joins to ZC thru association, then rejoins using Orphan procedure.
