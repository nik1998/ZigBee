start_zc start as ZC, start_ze joins to it, then tests check AIB, NIB and PIB, SET/GET functionality.

To start tests:
run ./run.sh

check log file for end device.
