Test checks whether intra PAN portability works correct. 

Run ./run.sh
Check .pcap files
