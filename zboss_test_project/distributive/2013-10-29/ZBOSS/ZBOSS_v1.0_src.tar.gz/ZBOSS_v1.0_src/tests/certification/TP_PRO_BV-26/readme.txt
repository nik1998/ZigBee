Test procedure: has 2 devices - ZC and ZR
ZC does Formation procedure, including Energy and Active scan.
ZR does Discovery then Join to the network at ZC.
Security is switched off.

To run this test, type:
sh run.sh

After test complete analyze traffic dump files.
