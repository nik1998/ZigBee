1. First of all, run ./prepare.sh script file.
2. Then run ./rebuild.sh.
3. You may have to launch ./build.sh several times after the 2nd step completed.
4. Copy all files from ws_config to your ~/.wireshark directory.
5. Run ./start.sh.
