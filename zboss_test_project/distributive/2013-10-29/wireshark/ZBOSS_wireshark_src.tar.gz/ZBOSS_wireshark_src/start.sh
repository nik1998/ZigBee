#/bin/sh

source options

cd $TARGET_WIRESHARK_DIR
./wireshark &
cd ../
